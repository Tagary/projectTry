declare interface IOneImage {
    albumId: number;
    id: number;
    title: string;
    url: string;
    thumbnailUrl: string;
}