import React from 'react';

function ImageDetails() {
  return <div>ImageDetails</div>;
}

export default ImageDetails;
