import axios from 'axios';
import React from 'react';
import ImageItem from '../Components/ImageItem';

function Galery() {

  return (
    <div className="d-flex ">

        <ImageItem/>
    </div>
  );
}

export default Galery;
