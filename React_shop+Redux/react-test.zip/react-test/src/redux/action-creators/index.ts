import * as ImageActionCreators from './image'

export default {
    ...ImageActionCreators,
}