export { default as DirectoryContr } from './DirectoryContr';
export { default as NewsEditor } from './NewsEditor';
export { default as OrganisationStructur } from './OrganisationStructur';
export { default as PersonalData } from './PersonalData';
export { default as UserControl } from './UserControl';
export {default as NewNewsModal} from './NewNewsModal'
export {default as NewsEditorModal} from './NewsEditorModal'