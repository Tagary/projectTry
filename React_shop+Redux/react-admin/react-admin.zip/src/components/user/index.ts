export { default as DirectoryContr } from './DirectoryContr';
export { default as NewsEditor } from './NewsEditor';
export { default as OrganisationStructur } from './OrganisationStructur';
export { default as PersonalData } from './PersonalData';
export { default as UserControl } from './UserControl';
